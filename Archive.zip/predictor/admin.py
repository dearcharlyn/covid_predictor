from django.contrib import admin
from .models import CovidList
# Register your models here.

admin.site.register(CovidList)